# Douban_flask
The utility crawler obtains the data of the Douban movie ranking and visualizes it through the flask framework.
